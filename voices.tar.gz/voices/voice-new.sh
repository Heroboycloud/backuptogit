curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/pNInz6obpgDQGcFmaJgB/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": "We also offer a variety of pre-designed pages, including a homepage, about page, contact page, and more, to save users time and effort in setting up their sites. Plus, we include a selection of Google Fonts and icons to help users customize the look and feel of their sites.",
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output voice/newa.mp3
play-audio voice/newa.mp3
