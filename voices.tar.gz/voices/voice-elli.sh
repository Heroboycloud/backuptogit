curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/MF3mGyEYCl7XYWbV9V6O/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": "Provide clear documentation and tutorials: Offer detailed instructions on how to use your live HTML editor, as well as tips and tricks for getting the most out of its features. This will make it easier for potential buyers to understand and use your product.",
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output voice/elli.mp3
play-audio voice/elli.mp3
