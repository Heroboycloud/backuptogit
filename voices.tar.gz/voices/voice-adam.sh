curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/pNInz6obpgDQGcFmaJgB/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": "My name is Adam and welcome to my channel ",
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output voice/adam2.mp3
play-audio voice/adam2.mp3
