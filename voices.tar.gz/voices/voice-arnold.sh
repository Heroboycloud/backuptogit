curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/VR6AewLTigWG4xSOukaG/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": " My name is Arnold",
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output voice/arnold2167.mp3
play-audio voice/arnold2167.mp3
