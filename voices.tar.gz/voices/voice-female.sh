curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": $1,
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output $2


