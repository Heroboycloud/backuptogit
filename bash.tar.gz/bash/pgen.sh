mkdir projectgen
clear
cd projectgen
echo "Right inside the project...."
npm init
npm install express --save
npm install body-parser cors axios --save
npm install openai dotenv --save
npm install cookie-parser ansi --save
touch index.js
touch .env
echo "Enter location of template file> "
read temp
echo " "
cp $temp index.js
clear && uname -a && date && ls
node index.js
