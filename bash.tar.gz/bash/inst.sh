npm install -g vercel && vercel --version && vercel login && vercel
cd adamai && npm i firebase


