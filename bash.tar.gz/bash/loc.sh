local folder=termux-clipboard-get

clear
cd $folder
serve
