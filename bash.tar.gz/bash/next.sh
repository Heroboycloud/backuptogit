npx create-next-app@latest --js --eslint
echo -n "Name of App you created> "
read app

cd $app
touch .env.local
echo REPLICATE_API_TOKEN=r8_dFqi58K4yjDh3Vud4QtIooAMrQtfiPu3Cy585 > .env.local
npm run dev
mkdir -p pages/api/predictions
touch pages/api/predictions/index.js

