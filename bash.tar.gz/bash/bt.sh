clear
echo 'Ready to open bootstrapserver'
bash bootcss.sh
