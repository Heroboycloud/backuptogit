clear
cd /storage/42A3-63A8/cdnjs && ls
http-server

