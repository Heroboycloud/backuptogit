script -t 2> timing.log -a output.session
