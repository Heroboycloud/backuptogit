lo=$(termux-fingerprint)

echo $lo["failed_attempts"]
