ifconfig| grep inet
