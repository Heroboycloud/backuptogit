date && cal
