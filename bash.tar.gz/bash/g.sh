dd=$(whoami)
ssh -p dd@127.0.0.1
ssh-keygen -t rsa -b 4096

