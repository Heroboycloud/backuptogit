myarr=(9 4 6 7)
myarr+=(8 7 9)
vb="${myarr[*]}"
termux-toast $vb
echo $?
