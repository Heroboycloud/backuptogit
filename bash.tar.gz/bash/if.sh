lov=$1

if [[ -e "$lov" ]]
then
 echo 'it exists'
fi
echo "done" && exit
