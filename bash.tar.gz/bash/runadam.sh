cd adamai && npm run dev
