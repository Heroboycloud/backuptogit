termux-toast -g bottom "goodnite 🤗🤗 " && exit
