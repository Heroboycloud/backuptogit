red=$(tput setaf 1)
 green=$(tput setaf 2)
