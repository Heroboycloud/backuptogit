curl -X 'POST' \
  'https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM/stream' \
  -H 'accept: */*' \
  -H 'Content-Type: application/json' \
  -d '{
  "text": "Didi AI is a digital diviner designed to provide helpful and informative responses to your questions and inquiries with the help of artificial intelligence ",
  "voice_settings": {
    "stability": 0,
    "similarity_boost": 0
  }
}' --output sample.mp3

#voice=EXAVITQu4vr4xnSDxMaL

