echo "Hello ..."
shopt −s cdspell # Allows minor misspelling of directory
