clear
echo "Enter your directory> "
read dir
cd $dir
mkdir git
mkdir premium
cd premium
mkdir demo
mkdir dist
mkdir assets
touch {LICENSE,README.html,README.pdf,README.md,CODE_OF_CONDUCT,INSTALLATION.md,FAQ.html}
ls
echo "Finished and ready for distribution"
