gg=$(termux-clipboard-get)

cd $gg
serve
#termux-clipboard-set "http://localhost:8080"
