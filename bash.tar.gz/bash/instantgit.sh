#!/usr/bin/bash
clear && uname -a
echo " "
date
echo " "
cal
echo ".....Instant git pusher....."
echo "Directory to push> "
read dir
cd $dir
echo "Right now in the directory..."
ls
echo "Check the project name well...."
echo "Git dir: $dir"
echo "Ready to open README... "
sleep 4
nano README.md
echo "The git initializing....."
sleep 2
git init && git add .
echo "Enter commit message> "
read com

git commit -m "$com"
sleep 3
echo "Now the repo creation stage..."
gh repo create
echo "Finished....."
echo "Ready to delete $dir...."
sleep 2
rm  -i -rf $dir
