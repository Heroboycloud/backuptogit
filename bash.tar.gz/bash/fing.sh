#!/bin/bash

# Define the JSON string
json='{
"errors": [],
"failed_attempts": 0,
"auth_result": "AUTH_RESULT_SUCCESS"
}'

# Use jq to extract the values from the JSON string
errors=$(echo $json | jq -r '.errors')
failed_attempts=$(echo $json | jq -r '.failed_attempts')
auth_result=$(echo $json | jq -r '.auth_result')

# Check the values
if [ "$errors" == "[]" ]; then
echo "No errors"
else
echo "Errors found: $errors"
fi

if [ "$failed_attempts" -eq 0 ]; then
echo "No failed attempts"
else
echo "Failed attempts: $failed_attempts"
fi

if [ "$auth_result" == "AUTH_RESULT_SUCCESS" ]; then
echo "Authentication successful"
else
echo "Authentication failed"
fi
