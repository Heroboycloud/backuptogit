mkfifo ~/.tts
   while true; do cat ~/.tts; done | termux-tts-speak
