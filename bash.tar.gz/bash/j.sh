. b.sh

echo "ok"
cd /bvsh
pwd
ls
