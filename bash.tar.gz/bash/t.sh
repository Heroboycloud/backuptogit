#!/bin/bash 
# Embedding Ctl−H in a string. 
a="^H^H"       
# Two Ctl−H's (backspaces).
 echo "abcdef"     
# abcdef 
echo −n "abcdef$a "   # abcd f 
#  Space at end  ^      ^ Backspaces twice. 
echo −n "abcdef$a"    # abcdef #  No space at end      Doesn't backspace (why?).          # Results may not be quite as expected. 


echo; echo
