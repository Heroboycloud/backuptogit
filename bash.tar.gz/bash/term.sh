a="^T^T"
echo -n "$a"
