curl -L https://yt-dl.org/downloads/latest/youtube-dl -o ../usr/bin/youtube-dl
 chmod a+rx ../usr/bin/youtube-dl
