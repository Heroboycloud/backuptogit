cd /storage/emulated/0/Download/bootstrap-offline-docs-5.1/bootstrap-offline-docs-5.1
http-server
