cd Heroboycloud
git status
sleep 3
git push
