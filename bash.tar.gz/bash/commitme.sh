newcode(){
echo "$1 is new"
}

oldcode(){
echo "$1 is old"
}
bb(){
echo "directory not correct"
exit
}

clear
echo "##                                         "
echo "############.....Instant Github commit app...#############"
echo "##                                              "
uname -a && echo " " && date && echo " " && cal
echo " "
echo "Enter Project directory name> "
read dir

cd $dir && echo "Directory ${dir} successfully opened" || bb
echo "Is this a new Git project or old? Enter yes if new, no if old(yes/no)"
read answer
if [[ "$answer"="yes" ]]; then
   newcode $dir
elif [[ "$answer"="no" ]]; then
   oldcode $dir
else
   echo "Wrong input selected..." && exit
fi

newcode(){
echo "$1 is new"
}
oldcode(){
echo "$1 is old"
}
