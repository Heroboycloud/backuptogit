echo "Next app creator.."
npx create-next-app@latest --js --eslint
