pkg install ffmpeg
npm i -g editly

git clone https://github.com/mifi/editly.git

cd editly/examples

git clone https://github.com/mifi/editly-assets.git assets

editly --fast commonFeatures.json5
