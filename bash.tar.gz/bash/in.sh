cd storage/movies

npx create-react-app my-appjs
sleep 2
npm install -g expo-cli
echo "Ready to open Expo js acc: "
sleep 4
expo init mobile
expo signin -u user
