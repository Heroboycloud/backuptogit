echo 'Hello world!' > hello.txt
 echo 'Howdy world!' > howdy.txt
gzip hello.txt
gzip howdy.txt
cat hello.txt.gz howdy.txt.gz > new.txt.gz
gunzip new.txt.gz
clear
cat new.txt
