#!/usr/bin/env bash
echo "Who are you> "
read user
echo "What you do? "
read doing
echo "You are $user and ${doing}ing"
echo 'This is $user'
cry(){
[[ -z $2 ]] && echo "Second argument not supplied" || echo "Ok supplied it is $2"
# ok
[[ -e $1 ]] && echo "fine.." || echo "Really bad"
 [[ "dae"="da" ]] && pwd || echo "not equal"
return 0
}
cry "color5.sh"
cry "color2.sh"
cry "color.sh" "freedom"

